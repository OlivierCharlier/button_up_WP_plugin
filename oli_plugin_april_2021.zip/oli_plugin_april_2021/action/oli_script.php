<script>
    document.addEventListener('DOMContentLoaded', function() {
       window.onscroll = function(ev) {
       document.getElementById("cRetour").className = (window.pageYOffset > 100) ? "cVisible" : "cInvisible";
    };
    });
</script>